# HACKATHON EXPRESS 25th October 2023

## Instructions
- Make a repo in Github.
- Add a markdown sintax readme with your names and grade written inside.
- Make a text file named "solutions" with the solutions for each challenge.
- Make one file for each solving code.
- Commit each modification you do.

## Notes
- Feel free to use the technology you prefer.
- For each challenge you need a text file called c1 (for the challenge 1), c2(for the challenge2)...